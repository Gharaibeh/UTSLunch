//
//  Event.swift
//  UTSLunch1
//
//  Created by Hasan Nihro Hasan Gharaibeh on 28/5/17.
//  Copyright © 2017 Hasan Nihro Hasan Gharaibeh. All rights reserved.
//

import UIKit

class Event: NSObject {

}
