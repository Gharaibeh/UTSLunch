//
//  eventsHomeView.swift
//  UTSLunch1
//
//  Created by Hasan Nihro Hasan Gharaibeh on 27/5/17.
//  Copyright © 2017 Hasan Nihro Hasan Gharaibeh. All rights reserved.
//

import UIKit

class  eventTableCell: UITableViewCell {
   /* @IBOutlet weak var event_userprofileImg: UIImageView!
    @IBOutlet weak var event_eventDiscription: UILabel!
    @IBOutlet weak var event_eventImage: UIImageView!
    
    @IBOutlet weak var event_particepents: UILabel!
    @IBOutlet weak var event_userprofilename: UILabel!*/
    
    
    @IBOutlet weak var EventTable_userprofileImage: UIImageView!
    
    @IBOutlet weak var EventTable_username: UILabel!
    
    
    @IBOutlet weak var EventTable_eventDesc: UILabel!
    
    @IBOutlet weak var EventTable_NoOfPpl: UILabel!
    
    @IBOutlet weak var EventTable_eventPhoto1: UIImageView!
    
}
class eventsHomeView: UITableViewController {
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = tableView.dequeueReusableCell(withIdentifier: "eventCell", for: indexPath)
        
        //cell.textLabel?.text = "Section \(indexPath.section) Row \(indexPath.row)"
        let cell = tableView.dequeueReusableCell(withIdentifier: "eventCell", for: indexPath) as! eventTableCell

        
        cell.EventTable_NoOfPpl?.text = "3"
        cell.EventTable_username?.text = "Hasan"
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Events"//"Section \(section)"
    }

}
